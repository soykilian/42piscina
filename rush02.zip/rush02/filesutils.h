#ifdef FILESU_H_
# define FILESU_H_

char	*ft_fill_pointer(char *file_name);
int		file_size(char *file_name);

#endif
