#ifndef NUMBERS_H
# define NUMBERS_H

typedef struct s_numbers
{
	unsigned int		key;
	char				*value;
}	t_numbers;

typedef struct p_group
{
	int				pos;
	int 			group;
	unsigned int	zeros;
	int				size;
	int				n_digits;
}	p_g;
#endif
