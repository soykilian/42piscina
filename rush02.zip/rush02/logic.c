#include <unistd.h>
#include "logic.h"
#include "number.h"
void	ft_print(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}

void	ft_mapping(unsigned int n, t_numbers *nums, int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		if (nums[i].key == n)
		{
			ft_print(nums[i].value);
			break ;
		}
		i++;
	}
}

void	ft_three(int pos, char d, t_numbers *nums, int size)
{
	if (d == 48)
		return ;
	else if (pos == 2)
	{
		ft_mapping(d - 48, nums, size);
		write(1, " ", 1);
		ft_mapping(100, nums, size);
	}
	else if (pos == 1)
		ft_mapping((d - 48) * 10, nums, size);
	else if (pos == 0)
		ft_mapping(d - 48, nums, size);
}

void	ft_num(char unit, t_numbers *nums, int size)
{
	int	num;

	num = 10;
	num += unit - 48;
	ft_mapping(num, nums, size);
}
