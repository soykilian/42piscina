#ifdef CHECK_ARGS_H
# define CHECK_ARGS_H
unsigned int    ft_atoi(char *str);
int	check_args(int argc, char **argv);
#endif
