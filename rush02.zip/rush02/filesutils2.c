#include "number.h"
#include "filesutils.h"
#include "filesutils2.h"
#include <stdlib.h>
int	str_len(char *p, int index)
{
	int		i;
	int		size;
	int		space;

	i = index;
	size = 0;
	space = 0;
	while (p[i] != '\n')
	{
		if (p[i] == 32 && space == 0)
		{
			i++;
			size++;
			space = 1;
		}
		else if (p[i] == 32 && space == 1)
			i++;
		else
		{
			space = 0;
			size++;
			i++;
		}
	}
	return (size);
}

char	 *ft_get_string(char *p, int i)
{
	char	*str;
	int		j;

	j = 0;
	str = malloc(str_len(p, i));
	while (p[i] != '\n')
	{
		if (p[i] == ' ' && str[j] != ' ')
		{
			str[j] = ' ';
			j++;
		}
		else if (p[i] > 32 && p[i] < 127)
		{
			str[j] = p[i];
			j++;
		}
		i++;
	}
	return (str);
}

int	fill_dict_nums(t_numbers *nums, char *p)
{
	int			i;
	int			j;
	int			value;

	j = 0;
	i = -1;
	while (p[++i])
	{
		value = -1;
		nums[j].key = 0;
		while (p[i] != '\n')
		{
			if (p[i] > 47 && p[i] < 58 && value == -1)
				nums[j].key = (nums[j].key * 10) + p[i] - 48;
			else if (value == -1 && p[i] == ':')
				value = 0;
			else if (p[i] != 32 && value == 0)
			{
				nums[j].value = ft_get_string(p, i);
				value = 1;
			}
			i++;
		}
		if (value != 1)
			return (0);
		j++;
	}
	return (1);
	}
