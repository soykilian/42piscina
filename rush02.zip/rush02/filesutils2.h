#ifdef FILESUTILS2_H_
# define FILESUTILS2_H_

int	str_len(char *p, int index);
char	 *ft_get_str(char *p, int i);
void	fill_dict_nums(t_numbers *nums, char *p);

#endif
