#ifdef LOGIC_H
# define LOGIC_H
void	ft_num (char unit, t_numbers *nums, int size);
void	ft_three(int pos, char d, t_numbers *nums, int size);
void	ft_mapping(unsigned int n, t_numbers *nums, int size);
void	ft_print(char *str);
#endif
